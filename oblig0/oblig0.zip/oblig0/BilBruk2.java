public class BilBruk2{

	public static void main(String[] args){
		Bil2 bil = new Bil2("ek19821");
		bil.skriv();
	
	}
}
