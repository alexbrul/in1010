public class Person{

	Bil3 bil;

	public Person(Bil3 bil){
		this.bil = bil;
	}

	public void skrivBil(){
		System.out.println(bil.hentNummer());
	}

}
