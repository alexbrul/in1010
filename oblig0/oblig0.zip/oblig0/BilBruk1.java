public class BilBruk1{

	public static void main(String[] args){
		Bil1 bil = new Bil1();
		bil.skriv();
	
	}
}
