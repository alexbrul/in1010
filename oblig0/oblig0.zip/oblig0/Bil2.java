public class Bil2{
	public String skilt;
	

	public Bil2(String arg){
		this.skilt = arg;
	
	}
	public void skriv(){
		System.out.println(skilt);
	}

}
