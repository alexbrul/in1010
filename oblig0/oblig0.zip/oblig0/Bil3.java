public class Bil3{
	public String skilt;
	

	public Bil3(String arg){
		this.skilt = arg;
	}

	public void skriv(){
		System.out.println(skilt);
	}
	public String hentNummer(){
		return skilt;
	}

}
