public class BilBruk3{

	public static void main(String[] args){
		Bil3 bil = new Bil3("ek19821");
		Person alex = new Person(bil);
		alex.skrivBil();
	
	}
}
