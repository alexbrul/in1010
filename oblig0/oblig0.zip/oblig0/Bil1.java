public class Bil1{

	public void skriv(){
		System.out.println("Dette er en bil");
	}

}
